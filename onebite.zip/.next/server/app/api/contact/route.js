(()=>{var e={};e.id=746,e.ids=[746],e.modules={2502:e=>{"use strict";e.exports=import("prettier/plugins/html")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},27910:e=>{"use strict";e.exports=require("stream")},28354:e=>{"use strict";e.exports=require("util")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},38127:(e,t,r)=>{"use strict";r.r(t),r.d(t,{patchFetch:()=>I,routeModule:()=>O,serverHooks:()=>z,workAsyncStorage:()=>T,workUnitAsyncStorage:()=>C});var n={};r.r(n),r.d(n,{GET:()=>N,POST:()=>q});var s=r(96559),i=r(48088),o=r(37719),a=Object.defineProperty,d=Object.defineProperties,l=Object.getOwnPropertyDescriptors,c=Object.getOwnPropertySymbols,u=Object.prototype.hasOwnProperty,p=Object.prototype.propertyIsEnumerable,h=(e,t,r)=>t in e?a(e,t,{enumerable:!0,configurable:!0,writable:!0,value:r}):e[t]=r,m=(e,t)=>{for(var r in t||(t={}))u.call(t,r)&&h(e,r,t[r]);if(c)for(var r of c(t))p.call(t,r)&&h(e,r,t[r]);return e},f=(e,t)=>d(e,l(t)),g=(e,t,r)=>new Promise((n,s)=>{var i=e=>{try{a(r.next(e))}catch(e){s(e)}},o=e=>{try{a(r.throw(e))}catch(e){s(e)}},a=e=>e.done?n(e.value):Promise.resolve(e.value).then(i,o);a((r=r.apply(e,t)).next())}),y=class{constructor(e){this.resend=e}create(e){return g(this,arguments,function*(e,t={}){return yield this.resend.post("/api-keys",e,t)})}list(){return g(this,null,function*(){return yield this.resend.get("/api-keys")})}remove(e){return g(this,null,function*(){return yield this.resend.delete(`/api-keys/${e}`)})}},x=class{constructor(e){this.resend=e}create(e){return g(this,arguments,function*(e,t={}){return yield this.resend.post("/audiences",e,t)})}list(){return g(this,null,function*(){return yield this.resend.get("/audiences")})}get(e){return g(this,null,function*(){return yield this.resend.get(`/audiences/${e}`)})}remove(e){return g(this,null,function*(){return yield this.resend.delete(`/audiences/${e}`)})}};function b(e){return{attachments:e.attachments,bcc:e.bcc,cc:e.cc,from:e.from,headers:e.headers,html:e.html,reply_to:e.replyTo,scheduled_at:e.scheduledAt,subject:e.subject,tags:e.tags,text:e.text,to:e.to}}var v=class{constructor(e){this.resend=e}send(e){return g(this,arguments,function*(e,t={}){return this.create(e,t)})}create(e){return g(this,arguments,function*(e,t={}){let n=[];for(let t of e){if(t.react){if(!this.renderAsync)try{let{renderAsync:e}=yield r.e(794).then(r.bind(r,3794));this.renderAsync=e}catch(e){throw Error("Failed to render React component. Make sure to install `@react-email/render`")}t.html=yield this.renderAsync(t.react),t.react=void 0}n.push(b(t))}return yield this.resend.post("/emails/batch",n,t)})}},w=class{constructor(e){this.resend=e}create(e){return g(this,arguments,function*(e,t={}){if(e.react){if(!this.renderAsync)try{let{renderAsync:e}=yield r.e(794).then(r.bind(r,3794));this.renderAsync=e}catch(e){throw Error("Failed to render React component. Make sure to install `@react-email/render`")}e.html=yield this.renderAsync(e.react)}return yield this.resend.post("/broadcasts",{name:e.name,audience_id:e.audienceId,preview_text:e.previewText,from:e.from,html:e.html,reply_to:e.replyTo,subject:e.subject,text:e.text},t)})}send(e,t){return g(this,null,function*(){return yield this.resend.post(`/broadcasts/${e}/send`,{scheduled_at:null==t?void 0:t.scheduledAt})})}list(){return g(this,null,function*(){return yield this.resend.get("/broadcasts")})}get(e){return g(this,null,function*(){return yield this.resend.get(`/broadcasts/${e}`)})}remove(e){return g(this,null,function*(){return yield this.resend.delete(`/broadcasts/${e}`)})}update(e,t){return g(this,null,function*(){return yield this.resend.patch(`/broadcasts/${e}`,{name:t.name,audience_id:t.audienceId,from:t.from,html:t.html,text:t.text,subject:t.subject,reply_to:t.replyTo,preview_text:t.previewText})})}},$=class{constructor(e){this.resend=e}create(e){return g(this,arguments,function*(e,t={}){return yield this.resend.post(`/audiences/${e.audienceId}/contacts`,{unsubscribed:e.unsubscribed,email:e.email,first_name:e.firstName,last_name:e.lastName},t)})}list(e){return g(this,null,function*(){return yield this.resend.get(`/audiences/${e.audienceId}/contacts`)})}get(e){return g(this,null,function*(){return e.id||e.email?yield this.resend.get(`/audiences/${e.audienceId}/contacts/${(null==e?void 0:e.email)?null==e?void 0:e.email:null==e?void 0:e.id}`):{data:null,error:{message:"Missing `id` or `email` field.",name:"missing_required_field"}}})}update(e){return g(this,null,function*(){return e.id||e.email?yield this.resend.patch(`/audiences/${e.audienceId}/contacts/${(null==e?void 0:e.email)?null==e?void 0:e.email:null==e?void 0:e.id}`,{unsubscribed:e.unsubscribed,first_name:e.firstName,last_name:e.lastName}):{data:null,error:{message:"Missing `id` or `email` field.",name:"missing_required_field"}}})}remove(e){return g(this,null,function*(){return e.id||e.email?yield this.resend.delete(`/audiences/${e.audienceId}/contacts/${(null==e?void 0:e.email)?null==e?void 0:e.email:null==e?void 0:e.id}`):{data:null,error:{message:"Missing `id` or `email` field.",name:"missing_required_field"}}})}},k=class{constructor(e){this.resend=e}create(e){return g(this,arguments,function*(e,t={}){return yield this.resend.post("/domains",{name:e.name,region:e.region,custom_return_path:e.customReturnPath},t)})}list(){return g(this,null,function*(){return yield this.resend.get("/domains")})}get(e){return g(this,null,function*(){return yield this.resend.get(`/domains/${e}`)})}update(e){return g(this,null,function*(){return yield this.resend.patch(`/domains/${e.id}`,{click_tracking:e.clickTracking,open_tracking:e.openTracking,tls:e.tls})})}remove(e){return g(this,null,function*(){return yield this.resend.delete(`/domains/${e}`)})}verify(e){return g(this,null,function*(){return yield this.resend.post(`/domains/${e}/verify`)})}},A=class{constructor(e){this.resend=e}send(e){return g(this,arguments,function*(e,t={}){return this.create(e,t)})}create(e){return g(this,arguments,function*(e,t={}){if(e.react){if(!this.renderAsync)try{let{renderAsync:e}=yield r.e(794).then(r.bind(r,3794));this.renderAsync=e}catch(e){throw Error("Failed to render React component. Make sure to install `@react-email/render`")}e.html=yield this.renderAsync(e.react)}return yield this.resend.post("/emails",b(e),t)})}get(e){return g(this,null,function*(){return yield this.resend.get(`/emails/${e}`)})}update(e){return g(this,null,function*(){return yield this.resend.patch(`/emails/${e.id}`,{scheduled_at:e.scheduledAt})})}cancel(e){return g(this,null,function*(){return yield this.resend.post(`/emails/${e}/cancel`)})}},_="undefined"!=typeof process&&process.env&&process.env.RESEND_BASE_URL||"https://api.resend.com",S="undefined"!=typeof process&&process.env&&process.env.RESEND_USER_AGENT||"resend-node:4.5.1",E=class{constructor(e){if(this.key=e,this.apiKeys=new y(this),this.audiences=new x(this),this.batch=new v(this),this.broadcasts=new w(this),this.contacts=new $(this),this.domains=new k(this),this.emails=new A(this),!e&&("undefined"!=typeof process&&process.env&&(this.key=process.env.RESEND_API_KEY),!this.key))throw Error('Missing API key. Pass it to the constructor `new Resend("re_123")`');this.headers=new Headers({Authorization:`Bearer ${this.key}`,"User-Agent":S,"Content-Type":"application/json"})}fetchRequest(e){return g(this,arguments,function*(e,t={}){try{let r=yield fetch(`${_}${e}`,t);if(!r.ok)try{let e=yield r.text();return{data:null,error:JSON.parse(e)}}catch(t){if(t instanceof SyntaxError)return{data:null,error:{name:"application_error",message:"Internal server error. We are unable to process your request right now, please try again later."}};let e={message:r.statusText,name:"application_error"};if(t instanceof Error)return{data:null,error:f(m({},e),{message:t.message})};return{data:null,error:e}}return{data:yield r.json(),error:null}}catch(e){return{data:null,error:{name:"application_error",message:"Unable to fetch data. The request could not be resolved."}}}})}post(e,t){return g(this,arguments,function*(e,t,r={}){let n=new Headers(this.headers);r.idempotencyKey&&n.set("Idempotency-Key",r.idempotencyKey);let s=m({method:"POST",headers:n,body:JSON.stringify(t)},r);return this.fetchRequest(e,s)})}get(e){return g(this,arguments,function*(e,t={}){let r=m({method:"GET",headers:this.headers},t);return this.fetchRequest(e,r)})}put(e,t){return g(this,arguments,function*(e,t,r={}){let n=m({method:"PUT",headers:this.headers,body:JSON.stringify(t)},r);return this.fetchRequest(e,n)})}patch(e,t){return g(this,arguments,function*(e,t,r={}){let n=m({method:"PATCH",headers:this.headers,body:JSON.stringify(t)},r);return this.fetchRequest(e,n)})}delete(e,t){return g(this,null,function*(){let r={method:"DELETE",headers:this.headers,body:JSON.stringify(t)};return this.fetchRequest(e,r)})}},P=r(75745),R=r(92896);let j=new E(process.env.RESEND_API_KEY);async function q(e){try{await (0,P.A)();let{email:t,phone:r,message:n,name:s}=await e.json();if(!t||!s||!r)return Response.json({success:!1,error:"Missing required fields"},{status:400});let i=new R.A({name:s.trim(),email:t.trim().toLowerCase(),phone:r.trim(),message:n?.trim()||void 0}),o=await i.save();return await j.emails.send({from:"onboarding@resend.dev",to:"khanmahmud994@gmail.com",subject:"New Contact Form Submission",replyTo:t,html:`
        <!DOCTYPE html>
        <html lang="en">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>New Contact Form Submission</title>
        </head>
        <body style="margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; line-height: 1.6; color: #333333; background-color: #f8fafc;">
          <div style="max-width: 600px; margin: 0 auto; background-color: #ffffff; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
            <!-- Header -->
            <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px 40px; text-align: center;">
              <h1 style="margin: 0; color: #ffffff; font-size: 28px; font-weight: 600; letter-spacing: -0.5px;">
                📧 New Contact Submission
              </h1>
              <p style="margin: 8px 0 0 0; color: #e2e8f0; font-size: 16px; opacity: 0.9;">
                Someone reached out through your contact form
              </p>
              <p style="margin: 4px 0 0 0; color: #e2e8f0; font-size: 14px; opacity: 0.7;">
                ID: ${o._id}
              </p>
            </div>
            
            <!-- Content -->
            <div style="padding: 40px;">
              <!-- Contact Info Cards -->
              <div style="margin-bottom: 30px;">
                <!-- Name Card -->
                <div style="background-color: #f8fafc; border-left: 4px solid #3b82f6; padding: 20px; margin-bottom: 16px; border-radius: 0 8px 8px 0;">
                  <div style="display: flex; align-items: center; margin-bottom: 8px;">
                    <span style="font-size: 18px; margin-right: 8px;">👤</span>
                    <strong style="color: #1e293b; font-size: 14px; text-transform: uppercase; letter-spacing: 0.5px;">Full Name</strong>
                  </div>
                  <p style="margin: 0; font-size: 18px; color: #334155; font-weight: 500;">${s}</p>
                </div>
                
                <!-- Email Card -->
                <div style="background-color: #f0fdf4; border-left: 4px solid #10b981; padding: 20px; margin-bottom: 16px; border-radius: 0 8px 8px 0;">
                  <div style="display: flex; align-items: center; margin-bottom: 8px;">
                    <span style="font-size: 18px; margin-right: 8px;">📧</span>
                    <strong style="color: #1e293b; font-size: 14px; text-transform: uppercase; letter-spacing: 0.5px;">Email Address</strong>
                  </div>
                  <p style="margin: 0; font-size: 18px; color: #334155; font-weight: 500;">
                    <a href="mailto:${t}" style="color: #10b981; text-decoration: none;">${t}</a>
                  </p>
                </div>
                
                <!-- Phone Card -->
                <div style="background-color: #fef3c7; border-left: 4px solid #f59e0b; padding: 20px; margin-bottom: 16px; border-radius: 0 8px 8px 0;">
                  <div style="display: flex; align-items: center; margin-bottom: 8px;">
                    <span style="font-size: 18px; margin-right: 8px;">📱</span>
                    <strong style="color: #1e293b; font-size: 14px; text-transform: uppercase; letter-spacing: 0.5px;">Phone Number</strong>
                  </div>
                  <p style="margin: 0; font-size: 18px; color: #334155; font-weight: 500;">
                    <a href="tel:${r}" style="color: #f59e0b; text-decoration: none;">${r}</a>
                  </p>
                </div>
              </div>
              
              <!-- Message Section -->
              ${n?`
                <div style="margin-top: 30px;">
                  <div style="display: flex; align-items: center; margin-bottom: 16px;">
                    <span style="font-size: 20px; margin-right: 8px;">💬</span>
                    <h3 style="margin: 0; color: #1e293b; font-size: 18px; font-weight: 600;">Message</h3>
                  </div>
                  <div style="background-color: #f1f5f9; border-radius: 12px; padding: 24px; border: 1px solid #e2e8f0;">
                    <p style="margin: 0; font-size: 16px; line-height: 1.7; color: #475569; white-space: pre-wrap;">${n}</p>
                  </div>
                </div>
              `:`
                <div style="margin-top: 30px; padding: 20px; background-color: #fef2f2; border-radius: 8px; border-left: 4px solid #ef4444;">
                  <p style="margin: 0; color: #7f1d1d; font-style: italic;">
                    <span style="margin-right: 8px;">ℹ️</span>
                    No message was provided with this submission.
                  </p>
                </div>
              `}
              
              <!-- Quick Actions -->
              <div style="margin-top: 40px; padding-top: 30px; border-top: 2px solid #e2e8f0;">
                <h3 style="margin: 0 0 20px 0; color: #1e293b; font-size: 16px; font-weight: 600;">Quick Actions</h3>
                <div style="display: flex; gap: 12px; flex-wrap: wrap;">
                  <a href="mailto:${t}" style="display: inline-block; background-color: #3b82f6; color: #ffffff; padding: 12px 20px; text-decoration: none; border-radius: 6px; font-weight: 500; font-size: 14px; margin-right: 10px;">
                    Reply via Email
                  </a>
                  <a href="tel:${r}" style="display: inline-block; background-color: #10b981; color: #ffffff; padding: 12px 20px; text-decoration: none; border-radius: 6px; font-weight: 500; font-size: 14px;">
                    Call Now
                  </a>
                </div>
              </div>
            </div>
            
            <!-- Footer -->
            <div style="background-color: #f8fafc; padding: 20px 40px; text-align: center; border-top: 1px solid #e2e8f0;">
              <p style="margin: 0; color: #64748b; font-size: 14px;">
                This email was sent from your contact form on ${new Date().toLocaleDateString("en-US",{weekday:"long",year:"numeric",month:"long",day:"numeric",hour:"2-digit",minute:"2-digit"})}
              </p>
            </div>
          </div>
        </body>
        </html>
      `}),Response.json({success:!0,data:{id:o._id,message:"Contact form submitted successfully"}})}catch(e){if(console.error("Contact form submission error:",e),"ValidationError"===e.name){let t=Object.values(e.errors).map(e=>e.message);return Response.json({success:!1,error:"Validation failed",details:t},{status:400})}return Response.json({success:!1,error:"Failed to process contact form submission"},{status:500})}}async function N(e){try{await (0,P.A)();let{searchParams:t}=new URL(e.url),r=Math.max(1,parseInt(t.get("page")||"1")),n=Math.min(100,Math.max(1,parseInt(t.get("limit")||"10"))),s=(r-1)*n,i=t.get("status"),o=t.get("search"),a=t.get("email"),d=t.get("dateFrom"),l=t.get("dateTo"),c=t.get("sortBy")||"createdAt",u="asc"===t.get("sortOrder")?1:-1,p={};i&&["pending","contacted","ordered","delivered","closed"].includes(i)&&(p.status=i),a&&(p.email={$regex:a,$options:"i"}),o&&(p.$or=[{name:{$regex:o,$options:"i"}},{email:{$regex:o,$options:"i"}},{message:{$regex:o,$options:"i"}}]),(d||l)&&(p.createdAt={},d&&(p.createdAt.$gte=new Date(d)),l&&(p.createdAt.$lte=new Date(l)));let h={};["createdAt","updatedAt","name","email","status"].includes(c)?h[c]=u:h.createdAt=-1;let[m,f]=await Promise.all([R.A.find(p).sort(h).skip(s).limit(n).lean(),R.A.countDocuments(p)]),g=Math.ceil(f/n),y=r<g,x=r>1;return Response.json({success:!0,data:m,pagination:{currentPage:r,totalPages:g,totalCount:f,limit:n,hasNextPage:y,hasPrevPage:x,nextPage:y?r+1:null,prevPage:x?r-1:null},filters:{status:i,search:o,email:a,dateFrom:d,dateTo:l,sortBy:c,sortOrder:1===u?"asc":"desc"}})}catch(e){return console.error("Error fetching contacts:",e),Response.json({success:!1,error:"Failed to fetch contacts"},{status:500})}}let O=new s.AppRouteRouteModule({definition:{kind:i.RouteKind.APP_ROUTE,page:"/api/contact/route",pathname:"/api/contact",filename:"route",bundlePath:"app/api/contact/route"},resolvedPagePath:"D:\\projects\\one-bite\\src\\app\\api\\contact\\route.ts",nextConfigOutput:"",userland:n}),{workAsyncStorage:T,workUnitAsyncStorage:C,serverHooks:z}=O;function I(){return(0,o.patchFetch)({workAsyncStorage:T,workUnitAsyncStorage:C})}},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55511:e=>{"use strict";e.exports=require("crypto")},56037:e=>{"use strict";e.exports=require("mongoose")},57075:e=>{"use strict";e.exports=require("node:stream")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},75745:(e,t,r)=>{"use strict";r.d(t,{A:()=>a});var n=r(56037),s=r.n(n);let i=process.env.MONGODB_URI;if(!i)throw Error("Please define the MONGODB_URI environment variable inside .env.local");let o=global.mongoose;o||(o=global.mongoose={conn:null,promise:null});let a=async function(){if(o.conn)return o.conn;o.promise||(o.promise=s().connect(i,{bufferCommands:!1}).then(e=>e));try{o.conn=await o.promise}catch(e){throw o.promise=null,e}return o.conn}},78335:()=>{},83505:e=>{"use strict";e.exports=import("prettier/standalone")},84297:e=>{"use strict";e.exports=require("async_hooks")},92896:(e,t,r)=>{"use strict";r.d(t,{A:()=>o});var n=r(56037),s=r.n(n);let i=new n.Schema({name:{type:String,required:[!0,"Name is required"],trim:!0,maxlength:[100,"Name cannot exceed 100 characters"]},email:{type:String,required:[!0,"Email is required"],trim:!0,lowercase:!0,match:[/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/,"Please enter a valid email address"]},phone:{type:String,required:[!0,"Phone number is required"],trim:!0,maxlength:[20,"Phone number cannot exceed 20 characters"]},message:{type:String,trim:!0,maxlength:[1e3,"Message cannot exceed 1000 characters"]},status:{type:String,enum:["pending","contacted","ordered","delivered","closed"],default:"pending"}},{timestamps:!0,toJSON:{virtuals:!0},toObject:{virtuals:!0}});i.index({email:1}),i.index({createdAt:-1}),i.index({status:1}),i.index({name:"text",message:"text"}),i.virtual("formattedDate").get(function(){return this.createdAt.toLocaleDateString("en-US",{year:"numeric",month:"long",day:"numeric",hour:"2-digit",minute:"2-digit"})});let o=s().models.Contact||s().model("Contact",i)},96487:()=>{},96559:(e,t,r)=>{"use strict";e.exports=r(44870)}};var t=require("../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),n=t.X(0,[719],()=>r(38127));module.exports=n})();