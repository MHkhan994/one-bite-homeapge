import SignInForm from "@/components/login/LoginForm";
import React from "react";

const Login = () => {
  return <SignInForm />;
};

export default Login;
